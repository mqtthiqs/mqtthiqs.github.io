
type 'a t = 'a list

exception Empty_stack

let empty = []
let push x s = s :: x
let pop = function
| [] -> raise Empty_stack
| x :: xs -> (xs, x)
let peek s n =
  try List.nth s n
  with Failure "nth" -> raise Empty_stack
let to_list x = x
let of_list x = x
