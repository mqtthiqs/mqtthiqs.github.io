
module List = struct
  include List

  let index p =
    let rec aux i = function
      | [] -> raise Not_found
      | x :: xs -> if p x then i else aux (i+1) xs
    in aux 0

  let prefix_index p xs =
    let rec aux n ys =
      if p xs ys then n else match ys with
      | [] -> raise Not_found
      | _ :: ys -> aux (n+1) ys
    in aux 0

  let rec flatten_map f = function
    | [] -> []
    | x :: xs -> f x @ flatten_map f xs

  let fold_left_i f =
    let rec it_list_f i a = function
      | [] -> a
      | b::l -> it_list_f (i+1) (f i a b) l
    in it_list_f

  let fold_right_i f i l =
    let rec it_f i l a = match l with
      | [] -> a
      | b::l -> f (i-1) b (it_f (i-1) l a)
    in it_f (List.length l + i) l

  let rec mapi i f = function
    | [] -> []
    | a::l -> let r = f i a in r :: mapi (i + 1) f l

  let mapi f l = mapi 0 f l

end

module Option = struct

  let cata f d = function
      | Some x -> f x
      | None -> d

end

module StringMap = Map.Make(struct type t = string let compare = String.compare end)
