#include <stdbool.h>

void button_init();
bool button_pressed();
