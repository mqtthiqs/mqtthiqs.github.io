#include <stdbool.h>

void leds_init();
void led_set(int led, bool state);
