open Util
open AST
open Instr

(* returns the position of a variable in the stack  *)
let lookup env : value_identifier -> int = function Identifier x ->
  try List.index ((=) (Named (Identifier x))) env
  with Not_found -> failwith ("Unbound identifier: " ^ x)

(* returns the integer identifer of a constructor *)
let lookup_cstr ctx : constructor_identifier -> int = function CIdentifier x ->
  try StringMap.find x ctx
  with Not_found -> failwith ("Unbound constructor " ^ x)

(* computes the free variables of a pattern *)
let rec free_pattern env = function
  | PAnd (p, q) | POr (p, q) -> free_pattern (free_pattern env p) q
  | PNot p -> free_pattern env p
  | PProd (_, ps) -> List.fold_left (fun env (_, p) -> free_pattern env p) env ps
  | PSum  (_, _, Some p) -> free_pattern env p
  | PSum  (_, _, None) | PZero | POne -> env
  | PVar x -> Named x :: env

(* computes the free variables of an expression *)
let rec free env k = function
  | EInt _ | EChar _ | EString _ -> k
  | EVar x -> if List.mem (Named x) env || List.mem x k then k else x :: k
  | ESum (_, _, e) -> Option.cata (free env k) k e
  | EProd (_, cs) -> List.fold_left
    (fun k (_, e) -> Option.cata (free env k) k e) k cs
  | EAnnot (e, _) -> free env k e
  | ESeq es -> List.fold_left (free env) k es
  | EDef (Simple (Binding (x, _), e1), e2) -> free env (free env k e1) e2
  | EDef (MutuallyRecursive bs, e) ->
    let env = List.fold_left (fun env (Binding (x, _), e) ->  x :: env) env bs in
    free env (List.fold_left (free env) k (List.map (fun (_, e) -> e) bs)) e
  | EApp (e1, e2) -> free env (free env k e1) e2
  | ECase (_, bs) -> List.fold_left
    (fun k (AST.Branch (p, e)) -> free (free_pattern env p) k e) k bs
  | EFun (Binding (x, _), e) -> free (x :: env) k e

let bind env x c f = match x with
    | Named _ -> [Branch (Seq c); Push; Branch (Seq (f (x :: env))); Pop 1]
    | Unnamed -> Branch (Seq c) :: f env

(* the main compilation function *)
let expr ctx =

  (* compiles an expression to intermediate code
     - ctx is an associative map from constructor name to integer identifiers
     - env is a list of variables giving (an approximation of) their position
       in the stack
     - the main invariant is that if [expr env e = l], then executing [l] in a
       stack [s] will lead to a state:
         - with the same stack [s]
         - the result of the execution will be in [acc]
  *)
  let rec expr env : expr -> interm instruction list = function
    | EInt i -> [Const i]
    | EChar c -> [Const (Char.code c)]
    | EString s -> [Str s]
    | EVar x -> [Acc (lookup env x)]
    | ESum (x, _, e) ->
      let c = lookup_cstr ctx x in
      Option.cata (fun e ->
        [Branch (Seq (expr env e)); Push; Makeblock (c, 1)]
      ) [Const c] e
    | EProd (_, cs) ->
      (* sort cs according to constructor number in ctx *)
      let es = List.map (function
        | x, Some e -> lookup_cstr ctx x, e
        | _ -> failwith "parse error") cs in
      let es = List.rev_map snd (List.sort (fun (m, _) (n, _) -> m-n) es) in
      let l = List.length es in
      (* compile the expressions and make the block *)
      let rec loop env = function
        | e :: es -> Branch (Seq (expr env e)) :: Push :: loop (Unnamed :: env) es
        | [] -> [Makeblock (0, l)]
      in loop env es
    | EAnnot (e, _) -> expr env e
    | ESeq es -> List.map (fun e -> Branch (Seq (expr env e))) es
    | EDef (MutuallyRecursive [Binding (f, _), EFun (Binding (x, _), e)], e2) ->
      let body =
        (* compute the free variables of the function's body minus f and x *)
        let fv = free [f; x] [] e in
        (* look them up in the current environment *)
        let vars = List.mapi (fun i x -> lookup env x + i) fv in
        (* the new environment consists only of variables in fv *)
        let env = List.rev_map (fun x -> Named x) fv in
        (* we push the vars on the stack before constructing the closure... *)
        List.fold_right (fun i is -> Acc i :: Push :: is) vars
          (* ...which code begins by saving the closure as f *)
          [Closure (List.length vars, Seq
            [Push; Branch (Seq (expr (f :: x :: env) e)); Pop 1])] in
      bind env f body (fun env -> expr env e2)
    | EDef (MutuallyRecursive (_ :: _ :: _), _) ->
      failwith "mutual recursion not implemented (yet)"
    | EDef (Simple (Binding (x, _), e1), e2)
    | EDef (MutuallyRecursive [Binding (x, _), e1], e2) ->
      bind env x (expr env e1) (fun env -> expr env e2)
    | EDef (MutuallyRecursive bs, e) -> assert false
    | EApp (ECase (_, [AST.Branch (PSum (CIdentifier "True", _, None), e1);
                 AST.Branch (PSum (CIdentifier "False", _, None), e2)]), e) ->
      Branch (Seq (expr env e)) :: Branchif (Seq (expr env e1)) :: expr env e2
    | EApp (ECase (_, bs), e) -> Branch (Seq (expr env e)) :: branches env bs
    | EApp (e1, e2) ->
      Branch (Seq (expr env e2)) :: Push ::
        Branch (Seq (expr (Unnamed :: env) e1)) :: [Apply]
    | ECase (t, bs) ->
      expr env (EFun (Binding (Named (Identifier " arg"), t),
                      EApp (ECase (t, bs), EVar (Identifier " arg"))))
    | EFun (Binding (x, _), e) ->
      (* compute the free variables of (fun x => e) *)
      let fv = free [x] [] e in
      (* look them up in the current environment *)
      let vars = List.mapi (fun i x -> lookup env x + i) fv in
      (* the new environment consists only of variables in fv *)
      let env = List.rev_map (fun x -> Named x) fv in
      (* we push the vars on the stack before constructing the closure *)
      List.fold_right (fun i is -> Acc i :: Push :: is) vars
        [Closure (List.length vars, Seq (expr (x :: env) e))]

  (* compiles pattern-matching branches to instructions *)
  and branches env : branches -> interm instruction list = function
    | _ -> failwith "pattern-matching compilation not implemented (yet)"

  in expr

(* compiles a type declaration into a context assigning integers to
   constructor identifiers *)
let rec typ ctx = function
  | TVar _ -> ctx
  | TArrow (a, b) -> typ (typ ctx a) b
  | TSum cs -> List.fold_left_i
    (fun i ctx (TConstructor (CIdentifier x, t)) ->
      let ctx = StringMap.add x i ctx in
      Option.cata (typ ctx) ctx t
    ) 0 ctx cs
  | TProd cs -> List.fold_left_i
    (fun i ctx (TConstructor (CIdentifier x, t)) ->
      let ctx = StringMap.add x i ctx in
      Option.cata (typ ctx) ctx t
    ) 0 ctx cs
  | TRec (_, t) -> typ ctx t

(* compiles a program into intermediate code *)
let rec program ctx env : program -> interm instruction list = function
  | [] -> []
  | DType (_, _, t) :: p -> program (typ ctx t) env p
  | DVal (Simple (Binding (x, _), e)) :: p ->
    bind env x (expr ctx env e) (fun env -> program ctx env p)
  | DVal (MutuallyRecursive b) :: p ->
    failwith "mutual recursion not implemented (yet)"

(* main program compilation function: calls [program] including the
   primitives *)
let program p =
  let env, prim = List.split Prim.prim in
  let env = List.rev_map (fun x -> Named (Identifier x)) env in
  let prim = List.fold_right (fun (Seq x) acc -> x @ Push :: acc) prim [] in
  Seq (Branch (Seq prim) :: program StringMap.empty env p)

(* converts intermediate code to list of bytecode instructions, i.e.,
   linearizes the code by squashing Branch'es, putting function code
   at the end and putting Branchif's code after the nearest enclosing
   Branch *)
let rec interm c = function
  | Branchif (Seq is) :: js ->
    let is = interm [] is and js = interm [] js in
    Branchif (List.length js+1) :: js @ Branch (List.length is) :: is @ c
  | i :: is -> instr (interm c is) i
  | [] -> c

and instr c = function
  | Closure (n, Seq is) -> Closure (n, List.length c) :: c @ interm [Return n] is
  | Branch (Seq is) -> interm c is
  | Branchif _ -> assert false  (* already treated in interm *)
  | Halt | Binop _ | Const _ | Push | Acc _ | Print
  | Apply | Return _ | Str _ | Makeblock _ | Getblock _
  | Pop _ as i -> i :: c

(* main backend: compiles intermediate code to bytecode *)
let interm (Seq is) = Array.of_list (interm [Halt] is)
