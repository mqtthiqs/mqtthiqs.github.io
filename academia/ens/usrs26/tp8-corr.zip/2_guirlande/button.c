#include <stdbool.h>

#include "stm32f3xx.h"
#include "system_stm32f3xx.h"

void button_init() {
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitTypeDef gpio = {0};
  gpio.Pin = GPIO_PIN_0;
  gpio.Mode = GPIO_MODE_INPUT;

  HAL_GPIO_Init(GPIOA, &gpio);
}

bool button_pressed() {
  return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
}
