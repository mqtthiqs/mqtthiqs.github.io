
void uart_init();
void uart_transmit(uint8_t data);

/* à implémenter par l'utilisateur */
void uart_on_receive(uint8_t data);
