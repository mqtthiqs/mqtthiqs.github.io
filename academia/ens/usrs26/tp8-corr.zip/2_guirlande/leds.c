#include <stdbool.h>

#include "stm32f3xx.h"
#include "system_stm32f3xx.h"

void leds_init() {
  __HAL_RCC_GPIOE_CLK_ENABLE();
  GPIO_InitTypeDef gpio = {0};
  gpio.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11
    | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  gpio.Pull = GPIO_PULLUP;

  HAL_GPIO_Init(GPIOE, &gpio);
}

/* led < 8 */
void led_set(int led, bool state) {
  int p =
    led == 0 ? GPIO_PIN_8 :
    led == 1 ? GPIO_PIN_9 :
    led == 2 ? GPIO_PIN_10 :
    led == 3 ? GPIO_PIN_11 :
    led == 4 ? GPIO_PIN_12 :
    led == 5 ? GPIO_PIN_13 :
    led == 6 ? GPIO_PIN_14 :
    GPIO_PIN_15;

  HAL_GPIO_WritePin(GPIOE, p, state);
}
