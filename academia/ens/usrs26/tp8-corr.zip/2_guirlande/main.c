#include <stdbool.h>

#include "stm32f3xx.h"
#include "system_stm32f3xx.h"

#include "leds.h"
#include "button.h"
#include "uart.h"

void delay() {
  for (float x=0.0f; x<1.0f; x += 0.00001f);
}

uint8_t counter = 0;

void SysTick_Handler() {
  HAL_IncTick();

  if(HAL_GetTick() % 32 == 0) {
    if (button_pressed()) {
      /* mode serveur */
      uart_transmit(counter++);
    } else {
      /* mode client */
    }
  }
}

void uart_on_receive(uint8_t data) {
  if (button_pressed()) {
    /* mode serveur */
    counter = 0;
  } else {
    /* mode client */
    bool s = data & 1;          /* data % 2 == 0 */
    int l = (data >> 1) & 0b111; /* (data / 2) % 8 */
    int c = (data >> 4);
    if (c==0) {
      /* le message m'est destiné */
      led_set(l, ! s);
    } else {
      /* je passe le message */
      c--;
      data = c << 4 | l << 1 | s;
      /* ou: data -= 16 */
      uart_transmit(data);
    }
  }
}

int main()
{
  leds_init();
  button_init();
  uart_init();
  HAL_Init();

  while(1) { }
}
