#include "stm32f3xx.h"
#include "system_stm32f3xx.h"

int main()
{
  __HAL_RCC_USART1_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  GPIO_InitTypeDef gpio_init = {0};
  gpio_init.Pin = GPIO_PIN_4 | GPIO_PIN_5;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  gpio_init.Alternate = GPIO_AF7_USART1;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  HAL_GPIO_Init(GPIOC, &gpio_init);

  UART_HandleTypeDef uart_handle = {0};
  uart_handle.Instance = USART1;
  uart_handle.Init.BaudRate = 9600;
  uart_handle.Init.Mode = UART_MODE_TX_RX;
  uart_handle.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&uart_handle);

  char data[] = "x mississippi\r\n";

  while(1) {
    HAL_UART_Receive(&uart_handle, data, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&uart_handle, data, 15, HAL_MAX_DELAY);
  }
}
