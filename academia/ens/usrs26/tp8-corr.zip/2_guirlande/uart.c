#include <stdbool.h>

#include "stm32f3xx.h"
#include "system_stm32f3xx.h"
#include "uart.h"

UART_HandleTypeDef uart_handle = {0};

uint8_t data;

void USART3_IRQHandler() {
  HAL_UART_IRQHandler(&uart_handle);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
  uart_on_receive(data);
  HAL_UART_Receive_IT(&uart_handle, &data, 1);
}

void uart_transmit(uint8_t data) {
  HAL_UART_Transmit_IT(&uart_handle, &data, 1);
}

void uart_init() {

  __HAL_RCC_USART3_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitTypeDef gpio_init = {0};
  gpio_init.Pin = GPIO_PIN_10 | GPIO_PIN_11;
  gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
  gpio_init.Alternate = GPIO_AF7_USART3;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  HAL_GPIO_Init(GPIOB, &gpio_init);

  uart_handle.Instance = USART3;
  uart_handle.Init.BaudRate = 9600;
  uart_handle.Init.Mode = UART_MODE_TX_RX;
  uart_handle.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&uart_handle);

  HAL_NVIC_EnableIRQ(USART3_IRQn);

  HAL_UART_Receive_IT(&uart_handle, &data, 1);
}
